package com.quality.soatFalabella;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MercuryTours_AutomatedTest {
	
	private WebDriver driver;
	By registerLinkLocator = By.linkText("Pago en l�nea");
	By registerPagelocator = By.xpath("//img[@src='//img[@src=https://sfestaticos.blob.core.windows.net/colombia/portal-pagos/logo.svg']");
	By registerCClocator = By.className("form-control ng-pristine ng-invalid ng-touched");
	//By registerAceptolocator = By.className("custom-control-input ng-dirty ng-touched ng-valid");
	//By registerConsultalocator = By.linkText("_ngcontent-serverapp-c35");


	@Before
	public void setUp() throws Exception {
		
		System.setProperty("webdriver.chrome.driver","./src/test/resources/chromedriver/chromedriver.exe");
		driver= new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://soat.segurosfalabella.com.co/sale/step0");
	}

	@After
	public void tearDown() throws Exception {
		//driver.quit();
	}

	@Test
	public void Registrer() {
		driver.findElement(registerLinkLocator).click();
		//Thread.sleep(2000);
		if(driver.findElement(registerPagelocator).isDisplayed()){	
			driver.findElement(registerCClocator).sendKeys("52123783");
			//driver.findElement(registerAceptolocator).click();
			//driver.findElement(registerConsultalocator).click();
		}		
		else {
			System.out.print("Registrer pages was not found");
		}
		}	
	}